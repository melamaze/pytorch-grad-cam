import cv2
import glob as glob
folder_name = ["./0/*", "./1/*", "./2/*", "./3/*", "./4/*", "./5/*", "./6/*", "./7/*", "./8/*", "./9/*", "./10/*", "./11/*", "./12/*", "./13/*", "./14/*", "./15/*", "./16/*", "./17/*", "./18/*", "./19/*", "./20/*", "./21/*", "./22/*", "./23/*", "./24/*", "./25/*", "./26/*", "./27/*", "./28/*", "./29/*", "./30/*", "./31/*", "./32/*", "./33/*", "./34/*", "./35/*", "./36/*", "./37/*", "./38/*", "./39/*", "./40/*", "./41/*", "./42/*"]

for folder in folder_name:
    print(folder)
    for image_path in glob.glob(folder):
        image = cv2.imread(image_path)
        image = cv2.resize(image, (32, 32), interpolation=cv2.INTER_AREA)
        print(image_path)
        for pos in range(3):
            image[0][27][pos] = 0
            image[0][28][pos] = 0
            image[0][29][pos] = 0
            image[0][30][pos] = 0
            image[1][26][pos] = 0
            image[1][27][pos] = 0
            image[1][28][pos] = 0
            image[1][29][pos] = 0
            image[1][30][pos] = 0
            image[1][31][pos] = 0
            image[2][27][pos] = 0
            image[2][30][pos] = 0
            image[3][28][pos] = 0
            image[3][29][pos] = 0
        cv2.imwrite(image_path, image)









